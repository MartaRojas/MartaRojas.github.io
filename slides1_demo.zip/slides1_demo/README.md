# Primeras transparencias usando Markdown.

Para generar las transparencias en formato HTML5 desde Sublime Text 2, existen dos opciones:

* Copiar el contenido del fichero genera_slides.bat en una línea de comandos Turtlestein y pulsar intro.

* Dar doble click directamente sobre el fichero genera_slides.bat.

En ambos casos, es necesario adaptar el nombre del fichero origen (por ejemplo, demo.md) al nombre de
vuestro fichero fuente Markdown.