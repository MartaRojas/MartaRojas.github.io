% Mitología Griega I
% Marta Rojas Martínez
% Primer Trimestre



# Mitología Griega I (Trimestre 1)

## Contenidos de la asignatura

+ Introducción 

+ Dioses

+ Diosas

+ Héroes

+ Actividades

# 1. INTRODUCCIÓN 

## Temario 

+ La antigua Grecia

+ ¿Qué es la mitología? ¿Qué es un mito?

+ Ciclos de relatos 

+ Generaciones

# 2. DIOSES 

## Los dioses que estudiaremos en esta evaluación serán:

1. Zeus

2. Poseidón

3. Hades

## APRENDEREMOS

* Procedencia
* Características principales 
* Mitos

# 3. DIOSAS

## Las diosas que estudiaremos en esta evaluación serán:

1. Hera

2. Afrodita

## APRENDEREMOS

* Procedencia
* Características principales 
* Mitos

# 4. HÉROES

## Los héroes que estudiaremos en esta evaluación serán:

1. Aquiles

2. Heracles

## APRENDEREMOS

* Procedencia
* Características principales 
* Mitos

# 5. ACTIVIDADES

## Las actividades evaluables serán:

* Actividades que se propongan durante el trimestre 
* Presentación parcial en pareja
* Actividad final en grupo (4 a 6 personas)









